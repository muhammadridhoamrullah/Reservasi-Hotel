<?php
    

$db = new PDO('mysql:host=ridhoamrullah10.my.id; dbname=ridhoamr_dbhotel', 'ridhoamr_hotel' , 'Qwer10101999');

?>