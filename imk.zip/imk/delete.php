<?php
include "database.php";

$query = "DELETE FROM hotelku WHERE id_user='$_GET[id_user]'";
$data = $db->prepare($query);
$data->execute();

header("location: index.php");
