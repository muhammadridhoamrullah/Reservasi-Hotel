<?php
include "database.php";
$query ="INSERT hotelku VALUES('','$_POST[dari]','$_POST[sampai]','$_POST[dewasa]','$_POST[balita]','$_POST[kamar]','$_POST[nama]' ,'$_POST[tipe]')";
$data = $db->prepare($query); //menyiapkan query sql
$data->execute(); //menjalankan perintah query sql

header("location:pesananmasuk.html");
?>