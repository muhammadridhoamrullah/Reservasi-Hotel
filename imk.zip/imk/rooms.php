<?php
    include "database.php";
?>
<!DOCTYPE html>
<html lang="zxx">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="Hotel Template">
    <meta name="keywords" content="Hotel, unica, creative, html">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Swiss-BelInn SKA</title>

    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css?family=Montserrat+Alternates:100,200,300,400,500,600,700,800,900&display=swap" rel="stylesheet">

    <!-- Css Styles -->
    <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">
    <link rel="stylesheet" href="css/font-awesome.min.css" type="text/css">
    <link rel="stylesheet" href="css/flaticon.css" type="text/css">
    <link rel="stylesheet" href="css/owl.carousel.min.css" type="text/css">
    <link rel="stylesheet" href="css/jquery-ui.min.css" type="text/css">
    <link rel="stylesheet" href="css/nice-select.css" type="text/css">
    <link rel="stylesheet" href="css/magnific-popup.css" type="text/css">
    <link rel="stylesheet" href="css/slicknav.min.css" type="text/css">
    <link rel="stylesheet" href="css/style.css" type="text/css">
</head>

<body>
    <!-- Page Preloder -->
    <div id="preloder">
        <div class="loader"></div>
    </div>

    <!-- Header Section Begin -->
    <header class="header-section">
        <div class="container-fluid">
            <div class="inner-header">
                <div class="logo">
                    <a href="./index.html"><img src="img/logosb22.png" alt=""></a>
                </div>
                <nav class="main-menu mobile-menu">
                    <ul>
                        <li><a href="./index.html">Beranda</a></li>
                        <li><a href="./about-us.html">Tentang Kami</a></li>
                        <li class="active"><a href="rooms.html">Kamar</a></li>
                        <li><a href="./contact.html">Hubungi Kami</a></li>
                    </ul>
                </nav>
                <div id="mobile-menu-wrap"></div>
            </div>
        </div>
    </header>
    <!-- Header End -->
    <!-- Hero Area Section End -->

    <!-- Search Filter Section Begin -->
   
    <!-- Search Filter Section End -->
    <!-- Search Filter Section Begin -->


    <!-- Room Section Begin -->
    <section class="room-section">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-6">
                    <div class="ri-slider-item">
                        <div class="ri-sliders owl-carousel">
                            <div class="single-img set-bg" data-setbg="img/suite3.jpg"></div>
                            <div class="single-img set-bg" data-setbg="img/suite2.jpg"></div>
                            <div class="single-img set-bg" data-setbg="img/suite1.jpg"></div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="ri-text">
                        <div class="section-title">
                            <div class="section-title">
                                <h2>Suite</h2>
                            </div>
                            <p>Kamar Suite yang luas seluas 47 meter persegi dan dirancang 
							dengan interior modern dan trendi dengan tema warna yang berbeda, 
							menyediakan semua kemewahan fasilitas suite untuk kenyamanan para tamu. 
							Setiap Suite dilengkapi dengan ruang tamu dan ruang makan terpisah, 
							kamar tidur dan kamar mandi yang luas..</p>
                            <div class="ri-features">
                                <div class="ri-info">
                                    <i class="flaticon-019-television"></i>
                                    <p>TV</p>
                                </div>
                                <div class="ri-info">
                                    <i class="flaticon-029-wifi"></i>
                                    <p>Wi-Fi</p>
                                </div>
                                <div class="ri-info">
                                    <i class="flaticon-003-air-conditioner"></i>
                                    <p>AC</p>
                                </div>
								<div class="ri-info">
                                    <i class="flaticon-020-telephone"></i>
                                    <p>Telephone</p>
                                </div>
                                <div class="ri-info">
                                    <i class="flaticon-030-bathtub"></i>
                                    <p>Bathtub</p>
                                </div>
                                <div class="ri-info">
                                    <i class="flaticon-004-fridge"></i>
                                    <p>Fridge</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <section class="search-filter">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-12">
                            <form method="post" action="insert.php" class="check-form">
                                <h4>Pesan Kamar</h4>
                                <div class="datepicker">
                                    <p>Dari</p>
                                    <input type="date" class="datepicker-1" value="" name="dari">
                                    <img src="img/calendar.png" alt="">
                                </div>
                                <div class="datepicker">
                                    <p>Sampai</p>
                                    <input type="date" class="datepicker-2" value="" name="sampai">
                                    <img src="img/calendar.png" alt="">
                                </div>
                                <div class="room-quantity">
                                    <div class="single-quantity">
                                        <p>Dewasa</p>
                                        <div class="pro-qty"><input type="text" value="0" name="dewasa"></div>
                                    </div>
                                    <div class="single-quantity">
                                        <p>Balita</p>
                                        <div class="pro-qty"><input type="text" value="0" name="balita"></div>
                                    </div>
                                    <div class="single-quantity last">
                                        <p>Kamar</p>
                                        <div class="pro-qty"><input type="text" value="0" name="kamar"></div>
                                    </div>
                                </div>
                                <div class="datepicker">
                                    <p>Atas Nama</p>
                                    <input  type="text" name="nama">
                                </div>
                                <button type="submit" value="Suite" name="tipe">PESAN</button>
								
                            </form>
                        </div>
                    </div>
                </div>
            </section>
            <div class="row">
                <div class="col-lg-6 order-lg-2">
                    <div class="ri-slider-item">
                        <div class="ri-sliders owl-carousel">
                            <div class="single-img set-bg" data-setbg="img/gdeluxe3.jpeg"></div>
                            <div class="single-img set-bg" data-setbg="img/gdeluxe2.jpeg"></div>
                            <div class="single-img set-bg" data-setbg="img/gdeluxe1.jpeg"></div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 order-lg-1">
                    <div class="ri-text left-side">
                        <div class="section-title">
                            <div class="section-title">
                                <h2>Grand Deluxe</h2>
                            </div>
                            <p>20 Kamar Deluxe dengan 12 tempat tidur Queen dan 8 tempat tidur Twin. 
							Setiap kamar dirancang dengan gaya minimalis dan trendi yang menyediakan fasilitas 
							standar hotel bintang 3 untuk kenyamanan para tamu. 
							Grand Deluxe terletak di lantai 9 - 10 dengan pemandangan kota di luar jendela.</p>
                            <div class="ri-features">
                                <div class="ri-info">
                                    <i class="flaticon-019-television"></i>
                                    <p>TV</p>
                                </div>
                                <div class="ri-info">
                                    <i class="flaticon-029-wifi"></i>
                                    <p>Wi-Fi</p>
                                </div>
                                <div class="ri-info">
                                    <i class="flaticon-003-air-conditioner"></i>
                                    <p>AC</p>
                                </div>
								<div class="ri-info">
                                    <i class="flaticon-020-telephone"></i>
                                    <p>Telephone</p>
                                </div>
                            </div>
                            
                        </div>
                    </div>
                </div>
            </div>
            <section class="search-filter">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-12">
                            <form method="post" action="insert.php" class="check-form">
                                <h4>Pesan Kamar</h4>
                                <div class="datepicker">
                                    <p>Dari</p>
                                    <input type="date" class="datepicker-1" value="" name="dari">
                                    <img src="img/calendar.png" alt="">
                                </div>
                                <div class="datepicker">
                                    <p>Sampai</p>
                                    <input type="date" class="datepicker-2" value="" name="sampai">
                                    <img src="img/calendar.png" alt="">
                                </div>
                                <div class="room-quantity">
                                    <div class="single-quantity">
                                        <p>Dewasa</p>
                                        <div class="pro-qty"><input type="text" value="0" name="dewasa"></div>
                                    </div>
                                    <div class="single-quantity">
                                        <p>Balita</p>
                                        <div class="pro-qty"><input type="text" value="0" name="balita"></div>
                                    </div>
                                    <div class="single-quantity last">
                                        <p>Kamar</p>
                                        <div class="pro-qty"><input type="text" value="0" name="kamar"></div>
                                    </div>
                                </div>
                                <div class="datepicker">
                                    <p>Atas Nama</p>
                                    <input type="text" name="nama">
                                </div>
                                <button type="submit" value="Grand Deluxe" name="tipe">PESAN</button>
								
                            </form>
                        </div>
                    </div>
                </div>
            </section>
            <div class="row">
                <div class="col-lg-6">
                    <div class="ri-slider-item">
                        <div class="ri-sliders owl-carousel">
                            <div class="single-img set-bg" data-setbg="img/deluxe1.jpeg"></div>
                            <div class="single-img set-bg" data-setbg="img/deluxe2.jpeg"></div>
                            <div class="single-img set-bg" data-setbg="img/deluxe3.jpeg"></div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="ri-text">
                        <div class="section-title">
                            <div class="section-title">
                                <h2>Deluxe</h2>
                            </div>
                            <p>Kamar Deluxe berukuran 24 m2, Masing-masing kamar didesain dengan minimalis dan bergaya trendi. 
							Kamar ini menyediakan fasilitas hotel bintang 3 untuk kenyamanan para tamu. 
							Kamar Deluxe tersedia dalam tempat tidur berukuran double atau single (pilihan)</p>
                            <div class="ri-features">
                                <div class="ri-info">
                                    <i class="flaticon-019-television"></i>
                                    <p>TV</p>
                                </div>
                                <div class="ri-info">
                                    <i class="flaticon-029-wifi"></i>
                                    <p>Wi-Fi</p>
                                </div>
                                <div class="ri-info">
                                    <i class="flaticon-003-air-conditioner"></i>
                                    <p>AC</p>
                                </div>
                                
                            </div>
                            
                        </div>
                    </div>
                </div>
            </div>
            
                    </div>
                </div>
            </div>
        </div>
        <section class="search-filter">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-12">
                            <form method="post" action="insert.php" class="check-form">
                                <h4>Pesan Kamar</h4>
                                <div class="datepicker">
                                    <p>Dari</p>
                                    <input type="date" class="datepicker-1" value="" name="dari">
                                    <img src="img/calendar.png" alt="">
                                </div>
                                <div class="datepicker">
                                    <p>Sampai</p>
                                    <input type="date" class="datepicker-2" value="" name="sampai">
                                    <img src="img/calendar.png" alt="">
                                </div>
                                <div class="room-quantity">
                                    <div class="single-quantity">
                                        <p>Dewasa</p>
                                        <div class="pro-qty"><input type="text" value="0" name="dewasa"></div>
                                    </div>
                                    <div class="single-quantity">
                                        <p>Balita</p>
                                        <div class="pro-qty"><input type="text" value="0" name="balita"></div>
                                    </div>
                                    <div class="single-quantity last">
                                        <p>Kamar</p>
                                        <div class="pro-qty"><input type="text" value="0" name="kamar"></div>
                                    </div>
                                </div>
                                <div class="datepicker">
                                    <p>Atas Nama</p>
                                    <input type="text" name="nama">
                                </div>
                                <button type="submit" value="Deluxe" name="tipe">PESAN</button>
								
                            </form>
                        </div>
                    </div>
                </div>
            </section>
    </section>
    <!-- Room Section End -->

    <!-- Footer Section Begin -->
    <footer class="footer-section">
        <div class="container">
            <div class="row">
                <div class="col-lg-4">
                    <div class="footer-item">
                        <div class="footer-logo">
                            <a href="#"><img src="img/logosb22.png" alt=""></a>
                        </div>
                        <p>“Simply the Best”</p>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="footer-item">
                        <h5>Berita</h5>
                        <div class="newslatter-form">
                            <input type="text" placeholder="Masukkan Email Anda">
                            <button type="submit">Berlangganan</button>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="footer-item">
                        <h5>Kontak</h5>
                        <ul>
                            <li><img src="img/placeholder.png" alt="">Complex SKA Mall ,
Jl. Soekarno-Hatta Lot 69 
<br />Pekanbaru ,  
Riau ,  
Indonesia</li>
                            <li><img src="img/phone.png" alt="">+62 761 61888</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <div class="copyright">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        
                        
                    </div>
                </div>
<div class="row pt-5">
                    <div class="col-lg-12 ">
                        <div class="small text-white text-center"><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
Copyright &copy;<script>document.write(new Date().getFullYear());</script> | Kelompok 3 IMK 
<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. --></div>
                    </div>
                </div>

            </div>
        </div>
    </footer>
    <!-- Footer Section End -->

    <!-- Js Plugins -->
    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.magnific-popup.min.js"></script>
    <script src="js/jquery-ui.min.js"></script>
    <script src="js/jquery.nice-select.min.js"></script>
    <script src="js/jquery.slicknav.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/main.js"></script>
</body>

</html>