<?php

include "database.php";

$query = "UPDATE hotelku SET dari='$_POST[dari]',sampai='$_POST[sampai]', dewasa='$_POST[dewasa]',balita='$_POST[balita]',kamar='$_POST[kamar]',nama='$_POST[nama]' WHERE id_user='$_POST[id_user]'";
$data = $db->prepare($query);
$data->execute();
header("location: index.php");
