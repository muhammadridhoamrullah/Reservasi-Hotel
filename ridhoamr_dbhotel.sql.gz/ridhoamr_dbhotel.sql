-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: ridhoamr_dbhotel
-- ------------------------------------------------------
-- Server version	10.1.44-MariaDB-cll-lve

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `hotelku`
--

DROP TABLE IF EXISTS `hotelku`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hotelku` (
  `id_user` int(5) NOT NULL AUTO_INCREMENT,
  `dari` date NOT NULL,
  `sampai` date NOT NULL,
  `dewasa` int(5) NOT NULL,
  `balita` int(5) NOT NULL,
  `kamar` int(5) NOT NULL,
  `nama` varchar(20) NOT NULL,
  `tipe` varchar(20) NOT NULL,
  PRIMARY KEY (`id_user`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hotelku`
--

LOCK TABLES `hotelku` WRITE;
/*!40000 ALTER TABLE `hotelku` DISABLE KEYS */;
INSERT INTO `hotelku` (`id_user`, `dari`, `sampai`, `dewasa`, `balita`, `kamar`, `nama`, `tipe`) VALUES (9,'2019-02-10','2019-01-11',1,1,1,'Ria','Suite'),(12,'2020-02-02','2020-02-03',2,1,1,'AFIF','Suite'),(14,'2020-06-30','2020-07-03',2,1,1,'Ridho','Suite'),(15,'2020-01-20','2020-01-25',1,0,1,'Justin','Grand Deluxe'),(16,'2020-03-10','2020-03-17',3,3,1,'Ari','Deluxe'),(17,'2020-06-24','2020-06-29',2,2,2,'User Testing','Grand Deluxe');
/*!40000 ALTER TABLE `hotelku` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'ridhoamr_dbhotel'
--

--
-- Dumping routines for database 'ridhoamr_dbhotel'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-06-30 15:31:54
